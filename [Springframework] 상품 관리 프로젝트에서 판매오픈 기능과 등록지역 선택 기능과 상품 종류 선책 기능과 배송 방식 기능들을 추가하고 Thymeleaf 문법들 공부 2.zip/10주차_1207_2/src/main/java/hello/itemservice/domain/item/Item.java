package hello.itemservice.domain.item;

import java.util.List;

import lombok.Data;

// 상품 도메인 모델 설계
@Data
public class Item {
	
	// long 타입 id
	private Long id;
	// String 타입 itemName
	private String itemName;
	// Integer 타입 price
	private Integer price;
	// Integer 타입 quantity
	private Integer quantity;
		
//	추가 필드 
	private Boolean open; // 판매 여부
	private List<String> regions; // 등록 지역
	private ItemType itemType; // 상품 종류
	private String deliveryCode; // 배송 방식
	
	public Item() {}
	
	public Item(String itemName, Integer price, Integer quantity) {
		this.itemName = itemName;
		this.price = price;
		this.quantity = quantity;
	}
	
}