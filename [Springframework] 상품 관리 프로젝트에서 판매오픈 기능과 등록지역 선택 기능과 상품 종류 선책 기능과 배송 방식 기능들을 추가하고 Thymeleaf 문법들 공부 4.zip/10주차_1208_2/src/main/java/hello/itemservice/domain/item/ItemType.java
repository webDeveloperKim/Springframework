package hello.itemservice.domain.item;

// 상품종류 정보저장
public enum ItemType {
	
	// 상품종류
	BOOK("도서"), FOOD("식품"), ETC("기타");
	
	// 상품설명
	private final String description;

	ItemType(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}
	
}
