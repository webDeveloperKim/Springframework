package hello.itemservice.domain.item;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
// 배송방식 정보 저장
public class DeliveryCode {
	private String code;
	private String displayName;
	
}
