package hello.itemservice.web.form;

import hello.itemservice.domain.item.DeliveryCode;
import hello.itemservice.domain.item.Item;
import hello.itemservice.domain.item.ItemRepository;
import hello.itemservice.domain.item.ItemType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/form/items")
@RequiredArgsConstructor
@Slf4j
public class FormItemController {

    private final ItemRepository itemRepository;

    // 목록 화면
    @GetMapping
    public String items(Model model) {
        List<Item> items = itemRepository.findAll();
        
        log.info("상품전체리스트={}", items);
        model.addAttribute("items", items);
        return "form/items";
    }

    // 상품 상세 화면
    // /form/items
    @GetMapping("/{itemId}")
    public String item(@PathVariable long itemId, Model model) {
        Item item = itemRepository.findById(itemId);
        
        log.info("상품상세={}", item);
        model.addAttribute("item", item);
        return "form/item";
    }

    // 상품등록 화면
    @GetMapping("/add")
    public String addForm(Model model) {
    	model.addAttribute("item", new Item());
        return "form/addForm";
    }

    // 상품등록 기능
    @PostMapping("/add")
    public String addItem(@ModelAttribute Item item, RedirectAttributes redirectAttributes) {
        Item savedItem = itemRepository.save(item);
        redirectAttributes.addAttribute("itemId", savedItem.getId());
        redirectAttributes.addAttribute("status", true);
        log.info("item.open={}", item.getOpen());
        log.info("item.regions={}", item.getRegions());
        return "redirect:/form/items/{itemId}";
        // 화면에서 체크박스 선택 후 submit 하면 on 이라는 값이 넘어감
        // 스프링 타입컨버터가 on 이라는 문자를 true 타입으로 변환해줌
    }

    // 상품수정 화면
    @GetMapping("/{itemId}/edit")
    public String editForm(@PathVariable Long itemId, Model model) {
        Item item = itemRepository.findById(itemId);
        model.addAttribute("item", item);
        return "form/editForm";
    }

    // 상품수정 기능
    @PostMapping("/{itemId}/edit")
    public String edit(@PathVariable Long itemId, @ModelAttribute Item item) {
        itemRepository.update(itemId, item);
        log.info("item.getOpen= {}",item.getOpen());
        log.info("item.getRegions= {}",item.getRegions());
        
        return "redirect:/form/items/{itemId}";
        // 화면에서 체크박스 선택 후 submit 하면 on 이라는 값이 넘어감 
        // 스프링 타입컨버터가 on 이라는 문자를 true 타입으로 변환해줌 
    }
        
    @ModelAttribute("regions")
    // 위 어노테이션 추가 시 regions 반환값을 자동으로 모델(model) 객체에 바인딩 해줌
    // @ModelAttribute 로 지정된 컨트롤러 메서드는
    // 모든 요청에서 공유되는 모델객체에 바인딩해줌
    // 그래서 별도 @RequestMapping 없이 다른 요청에서도 바인딩된 객체로 사용할 수 있음
    // --> 전역적으로 모든 뷰템플릿에서 접근할 수 있는 이유
    public Map<String, String> regions(){
    	Map<String, String> regions = new LinkedHashMap<>();
    	regions.put("SEOUL", "서울");
    	regions.put("BUSAN", "부산");
    	regions.put("JEJU", "제주");
    	
    	return regions;
    }
    
    @ModelAttribute("itemTypes")
    // ItemType ENUM의 모든 정보 배열로 반환 EX) [BOOK, FOOD, ETC]
    public ItemType[] itemTypes() {
    	log.info("item.BOOK={}",ItemType.BOOK);
    	log.info("item.FOOD={}",ItemType.FOOD);
    	log.info("item.ETC={}",ItemType.ETC);
    	for(ItemType itemType: ItemType.values()) {
    		log.info("item.vals--={}",itemType);
    	}
    	log.info("item.vals[book]={}",ItemType.valueOf("BOOK"));
    	log.info("item.vals[food]={}",ItemType.valueOf("FOOD"));
    	log.info("item.vals[etc]={}",ItemType.valueOf("ETC"));
    	
    	return ItemType.values(); //[BOOK, FOOD, ETC]
    }
    
    // @ModelAttribute("deliveryCodes") 함축코드
    // Model model = new Model();
    // model.setAttribute("deliveryCodes", deliveryCodes);
    @ModelAttribute("deliveryCodes") 
    public List<DeliveryCode> deliveryCodes(){
    	List<DeliveryCode> deliveryCodes = new ArrayList<>();
    	deliveryCodes.add(new DeliveryCode("FAST", "빠른 배송"));
    	deliveryCodes.add(new DeliveryCode("NORMAL", "일반 배송"));
    	deliveryCodes.add(new DeliveryCode("SLOW", "느린 배송"));
    	
    	log.info("방금추가한 리스트={}",deliveryCodes); 
    	
    	return deliveryCodes;
    }
    
}















